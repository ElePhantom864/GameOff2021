<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="modifiedspringstar" tilewidth="32" tileheight="32" tilecount="288" columns="18">
 <image source="modifiedspringstar.png" width="576" height="512"/>
</tileset>
